import React from "react";

const userSetting = () => {
 return <div>hello this is setting</div>;
};

export default userSetting;

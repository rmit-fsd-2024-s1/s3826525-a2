import React, { useEffect, useState } from 'react';
import { Main } from '../layouts/Main';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import valid from 'card-validator';
import { createOrder, getOrderDetailById } from '../../apis/order';
import { jwtDecode } from 'jwt-decode';
import { HOST_API_KEY } from '../../config';

const CheckOut = () => {
    const navigate = useNavigate();
    const [loginUser, setLoginUser] = useState(null)
    useEffect(() => {
        const jwtToken = localStorage.getItem('jwtToken');
        const user = jwtDecode(jwtToken)
        console.log("jwt token in procced", user)
        setLoginUser(user)
    }, [])

    const cartItemsData = localStorage.getItem('cartItems');
    const cartItems = JSON.parse(cartItemsData);
    console.log('cartItems: ', cartItems);
    const totalPrice = cartItems?.reduce((acc, item) => acc + item?.total, 0);
    function orderplace() {
        Swal.fire({
            title: 'Success',
            text: 'Successfully placed your order',
            icon: 'success',
            showConfirmButton: false,
            timer: 1000,
        });
        navigate('/');
    }
    const onSubmit = async (values, { resetForm }) => {
        console.log("cartItems at checkout",cartItems)
        try {
            const items = cartItems.map((item) => (
                {
                item_id: item?.id,
                quantity: item?.quantity,
                image:item?.image,
                price:item?.price,
                total:item?.total,
                name:item?.name,
            }));
            const createOrderRes = await createOrder({ user_id: loginUser?.id, items })
            if (createOrderRes.status === 201) {
                const orderId = createOrderRes?.data?.order?.id
                const orderDetailRes = await getOrderDetailById(orderId)
                if (orderDetailRes.status === 200) {
                    console.log("order detail", orderDetailRes.data)
                    localStorage.setItem('orderDetail', JSON.stringify(orderDetailRes.data));
                    resetForm();
                    orderplace();
                    setTimeout(() => {
                        navigate("/purchase-summry");
                    }, 1000);
                    localStorage.removeItem('cartItems');
                }
                else {
                    console.log("order detail", res.data)
                }
            }
            if (res.status === 400) {
                Swal.fire({
                    position: "center",
                    icon: "error",
                    title: res?.data?.message,
                    showConfirmButton: false,
                    timer: 1000,
                });
            }
        } catch (error) {
            console.log("Error:", error);
        }
    }
    const validationSchema = Yup.object().shape({
        cardNumber: Yup.string()
            .required('Card number is required')
            .test('test-card-number', 'Invalid card number', value => valid.number(value).isValid),
        expiry: Yup.string()
            .required('Expiry date is required')
            .test('test-expiry-date', 'Invalid expiry date', value => {
                const expiry = valid.expirationDate(value);
                return expiry.isValid && !expiry.isPast;
            }),
        cvv: Yup.string()
            .required('CVV is required')
            .test('test-cvv', 'Invalid CVV', function (value) {
                const cardNumber = this.parent.cardNumber;
                const cardType = valid.number(cardNumber).card;
                const cvvValidation = valid.cvv(value, cardType ? cardType.code.size : 3);
                return cvvValidation.isValid;
            }),
        cardHolderName: Yup.string()
            .required('Name of card holder is required')
            .matches(/^[A-Za-z ]+$/, 'Name must contain only letters'),
    });

    return (
        <Main>
            <div className='font-[sans-serif] bg-gray-50 p-6 min-h-screen'>
                <div className='max-w-7xl mx-auto'>
                    <h2 className='text-3xl font-extrabold text-[#333] text-center'>Checkout</h2>
                    <div className='grid lg:grid-cols-3 gap-8 mt-12'>
                        <div className='lg:col-span-2'>
                            <h3 className='text-xl font-bold text-[#333]'>Choose your payment method</h3>
                            <div className='grid gap-4 sm:grid-cols-2 mt-6'>
                                <div className='flex items-center'>
                                    <input
                                        type='radio'
                                        className='w-5 h-5 cursor-pointer'
                                        id='card'
                                        checked
                                    />
                                    <label for='card' className='ml-4 flex gap-2 cursor-pointer'>
                                        <img src='https://readymadeui.com/images/visa.webp' className='w-12' alt='card1' />
                                        <img src='https://readymadeui.com/images/american-express.webp' className='w-12' alt='card2' />
                                        <img src='https://readymadeui.com/images/master.webp' className='w-12' alt='card3' />
                                    </label>
                                </div>
                                <div className='flex items-center'>
                                    <input
                                        type='radio'
                                        className='w-5 h-5 cursor-pointer'
                                        id='paypal'
                                    />
                                    <label for='paypal' className='ml-4 flex gap-2 cursor-pointer'>
                                        <img src='https://readymadeui.com/images/paypal.webp' className='w-20' alt='paypalCard' />
                                    </label>
                                </div>
                            </div>
                            <Formik
                                initialValues={{
                                    cardNumber: '',
                                    expiry: '',
                                    cvv: '',
                                    cardHolderName: '',
                                }}
                                validationSchema={validationSchema}
                                onSubmit={onSubmit}
                            >
                                {({ errors, touched }) => (
                                    <Form className='mt-8'>
                                        <div className='grid gap-6'>
                                            <div className='grid sm:grid-cols-3 gap-6'>
                                                <div className="">
                                                    <Field
                                                        name='cardNumber'
                                                        placeholder='Card number'
                                                        className={`px-4 py-3.5 bg-white text-[#333] w-full text-sm border rounded-md focus:border-[#007bff] outline-none ${errors.cardNumber && touched.cardNumber ? 'border-red-500' : ''
                                                            }`}
                                                    />
                                                    <ErrorMessage name='cardNumber' component='div' className='text-red-500' />
                                                </div>
                                                <div className="">
                                                    <Field
                                                        type='text'
                                                        name='expiry'
                                                        placeholder='Expiry (MM/YY)'
                                                        className={`px-4 py-3.5 bg-white text-[#333] w-full text-sm border rounded-md focus:border-[#007bff] outline-none ${errors.expiry && touched.expiry ? 'border-red-500' : ''
                                                            }`}
                                                    />
                                                    <ErrorMessage name='expiry' component='div' className='text-red-500' />
                                                </div>
                                                <div className="">
                                                    <Field
                                                        name='cvv'
                                                        placeholder='CVV'
                                                        className={`px-4 py-3.5 bg-white text-[#333] w-full text-sm border rounded-md focus:border-[#007bff] outline-none ${errors.cvv && touched.cvv ? 'border-red-500' : ''
                                                            }`}
                                                    />
                                                    <ErrorMessage name='cvv' component='div' className='text-red-500' />
                                                </div>
                                            </div>
                                            <div className='sm:col-span-2 grid sm:grid-cols-2 gap-6'>
                                                <div className="">

                                                    <Field
                                                        type='text'
                                                        name='cardHolderName'
                                                        placeholder='Name of card holder'
                                                        className={`px-4 py-3.5 bg-white text-[#333] w-full text-sm border rounded-md focus:border-[#007bff] outline-none ${errors.cardHolderName && touched.cardHolderName ? 'border-red-500' : ''
                                                            }`}
                                                    />
                                                    <ErrorMessage name='cardHolderName' component='div' className='text-red-500' />
                                                </div>
                                                <div className="">

                                                    <Field
                                                        // type='number'
                                                        name='postalCode'
                                                        placeholder='Postal code'
                                                        className='px-4 py-3.5 bg-white text-[#333] w-full text-sm border rounded-md focus:border-[#007bff] outline-none'
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                        <div className='flex flex-wrap gap-4 mt-10 '>
                                            <button
                                                type='submit'
                                                className='px-6 py-3.5 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700'
                                            >
                                                Place order
                                            </button>
                                        </div>
                                    </Form>
                                )}
                            </Formik>
                        </div>
                        <div className='lg:border-l lg:pl-8'>
                            <h3 className='text-xl font-bold text-[#333]'>Summary</h3>
                            {cartItems?.map((items, i) => (
                                <div className="flex items-center justify-between py-2">
                                    <img src={`${HOST_API_KEY}${items?.image}`} alt="" className='w-[40px] h-[40px] cover' />
                                    <p className="">{items?.total}</p>
                                </div>
                            ))}
                            <ul className='text-[#333] mt-6 space-y-4'>
                                <li className='flex flex-wrap gap-4 text-sm'>
                                    SubTotal <span className='ml-auto font-bold'>${totalPrice}</span>
                                </li>
                                <li className='flex flex-wrap gap-4 text-sm'>
                                    Shipping <span className='ml-auto font-bold'>$4.00</span>
                                </li>
                                {/* <li className='flex flex-wrap gap-4 text-sm'>
                                    Discount (20%) <span className='ml-auto font-bold'>$8.00</span>
                                </li> */}
                                <li className='flex flex-wrap gap-4 text-sm'>
                                    Tax <span className='ml-auto font-bold'>$4.00</span>
                                </li>
                                <li className='flex flex-wrap gap-4 text-base font-bold border-t pt-4'>
                                    Total <span className='ml-auto'>${totalPrice + 8}</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </Main>
    );
};

export default CheckOut;


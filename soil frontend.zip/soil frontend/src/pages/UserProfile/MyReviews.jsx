import React, { useEffect, useState } from 'react'

import { CheckCircle } from "react-feather";

import { Main } from '../../layouts/Main';
import { Link, useParams } from 'react-router-dom';
import { getReviewsByUserId } from '../../../apis/review';
import { HOST_API_KEY } from '../../../config';
import ReactStars from 'react-stars';


const MyReviews = () => {
  const {id}=useParams()
  const [userReviews,setUserReviews]=useState([])
  console.log("id in my reviews",id)

  const fetchUserReviews = async()=>{
    try{
      const res = await getReviewsByUserId(id)
      console.log("res in my reviews",res.data)
      setUserReviews(res?.data)
    }
    catch(err){
      console.log(err)
    }
  }


  useEffect(()=>{
    fetchUserReviews()
  },[])

  return (
    <Main>
      <div className='flex justify-center items-center w-full'>
      <div className='flex justify-center items-center flex-col mx-10 my-4 px-4 py-4 lg:w-2/4 md:w-3/4 sm:w-full'> 
      <div className='flex justify-start items-center w-full'>
      <p className=' text-2xl my-7 font-bold text-left '>My Reviews</p>
      </div>
      {
        userReviews?.map((review) => {
          console.log("order in map ",review)
return (
  <div className='flex justify-center items-center flex-col bg-white shadow-md rounded-lg w-full my-2 px-3 py-3 pb-1 '>
    <div className='flex justify-center items-start w-full flex-col '>
      <p className=' text-black text-lg font-bold '>{review?.product.name}</p>
      <p className=' text-gray-400 text-sm  '>Purchased on {new Date(review?.created_at).toLocaleDateString('en-US')}</p>
    </div>
<div className=' bg-slate-50 flex justify-center items-center flex-col w-full my-2 px-2 '>

    
        <div className=' py-2 w-full flex justify-start items-center'>
          <div className='flex justify-start items-center'>
          <img className='w-[40px] h-[40px] cover' src={`${HOST_API_KEY}${review?.product?.image}`}/>
          </div>
          <div className='flex justify-start items-center ml-4'>
          <p>{review?.product?.description}</p>
          </div>
        </div>
  </div>
  <div className=' w-full flex justify-cente items-start flex-col'>
              <ReactStars
                count={5}
                value={review?.rating}
                size={24}
                color2={"#ffd700"}
                edit={false}
              />
            </div>
  <div className=' w-full flex justify-between items-start '>
           <p>{review?.comment}</p>
           <Link to={`/review/${review?.item_id}/${review?.order_id}`} className=' rounded-lg px-2 py-1 border-blue-300 border-[1px] hover:underline text-blue-600 '>
           Edit
           </Link>
    </div>
</div>



      
  )
        }
       )}
      </div>
      </div>
     
   
     

    </Main>
  )
}

export default MyReviews
import React from "react";

const UserLogOut = () => {
 return <div>this is user logout</div>;
};

export default UserLogOut;

// import React, { useState, useEffect } from 'react';
// import Swal from 'sweetalert2';
// import { useNavigate } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';
import {sendEmail } from '../../../apis/user';

const ChangePassword = () => {
    const Navigate = useNavigate();
      const user = jwtDecode(localStorage.getItem("jwtToken")) ;
      console.log('user: ', user);
    // Define initial form values
    const initialValues = {
      email: user.email,
    };
    // Define validation schema using Yup
    const validationSchema = Yup.object().shape({
      email: Yup.string().email('Invalid email address').required('Required'),
    });
  
    // Handle form submission
    const onSubmit = (values) => {
      // Submit logic here
      // Example: Save data to backend, update state, etc.
      console.log('Form submitted with values:', values);
      sendEmail(values).then((res)=>{
        console.log("res on update profile",res)
        if(res.status===200){
          console.log("res on update profile",res.data)
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: 'please check your email',
            showConfirmButton: false,
            timer: 1500,
          });
        }
        else{
          console.log("res on update profile",res)

        }
      })
      // Show success message
      // Redirect after submission
    
    };
  
    return (
      <div className="personalize-profile w-full h-screen flex flex-col items-center justify-center bg-gray-500">
        <div className="w-1/2 flex items-center justify-center flex-col bg-white rounded-md p-10">
          <h2 className="capitalize font-semibold text-4xl pb-4">Edit Profile</h2>
  
          {/* Formik Form */}
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={onSubmit}
          >
            {({ errors, touched }) => (
              <Form className="w-full flex flex-col gap-6">
             
                <div className="grid md:grid-cols-1 md:gap-6">
                  <div className="flex flex-col">
                    <label htmlFor="email">Email</label>
                    <Field
                      type="email"
                      name="email"
                      id="email"
                      className={`border-2 rounded border-gray-400 outline-none px-2 py-1 ${
                        errors.email && touched.email ? 'border-red-500' : ''
                      }`}
                    />
                    <ErrorMessage name="email" component="div" className="text-red-500" />
                  </div>
              
                </div>
                <button
                  type="submit"
                  className="text-white capitalize bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                >
                  Send Email
                </button>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    );
  };
  
  export default ChangePassword;
  


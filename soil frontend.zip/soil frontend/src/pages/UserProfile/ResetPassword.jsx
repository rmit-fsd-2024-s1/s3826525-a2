// import React, { useState, useEffect } from 'react';
// import Swal from 'sweetalert2';
// import { useNavigate } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { Link, useNavigate, useParams, useLocation } from "react-router-dom";
import Swal from 'sweetalert2';
import { jwtDecode } from 'jwt-decode';
import { UpdateUser, resetPassword } from '../../../apis/user';

const ResetPassword = () => {
    const location = useLocation();
 
    const searchParams = new URLSearchParams(location.search);
    const token = searchParams.get('token');
  
    const Navigate = useNavigate();
    const user = jwtDecode(localStorage.getItem("jwtToken"));
    // const user = existingItems ? JSON.parse(existingItems) : [];

    // user.push(data);
    // const updateduser = JSON.stringify(user);
    // localStorage.setItem("user", updateduser);
    // console.log("Item added to cart:", data);

    // Define initial form values
    const initialValues = {
        password: "",
        confirmPassword: "",
        // email: user.email,
        // password: user.password,
      };
    // Define validation schema using Yup
    const validationSchema = Yup.object().shape({
        password: Yup.string()
            .required("Required")
            .min(8)
            .required("Password must contain at least 8 characters")
            .matches(
                /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d!@#$%^&*()_+]{8,}$/,
                "password must have one uppercase letter, one lowercase letter, one number, and one special character"
            ),
        confirmPassword: Yup.string()
            .required('Required')
            .oneOf([Yup.ref('password'), null], 'Passwords must match')
    });

    // Handle form submission
    const onSubmit = (values) => {
        // Submit logic here
        // Example: Save data to backend, update state, etc.
       
        const newPassword = values?.password
       
        resetPassword(token, { password: newPassword }).then((res) => {
            if (res.status === 200) {
                console.log("res on change passowrd", res.data)
                Swal.fire({
                    position: 'center',
                    icon: 'success',
                    title: 'Password Changed successfully',
                    showConfirmButton: false,
                    timer: 1500,
                });
                setTimeout(() => {
                    Navigate('/user-profile');
                }, 1500);
            }
            else {
                console.log("res on update profile", res)

            }
        })
        // Show success message
        // Redirect after submission

    };

    return (
        <div className="personalize-profile w-full h-screen flex flex-col items-center justify-center bg-gray-500">
            <div className="w-1/2 flex items-center justify-center flex-col bg-white rounded-md p-10">
                <h2 className="capitalize font-semibold text-4xl pb-4">New password</h2>

                {/* Formik Form */}
                <Formik
                initialValues={initialValues}
                    validationSchema={validationSchema}
                    onSubmit={onSubmit}
                >
                    {({ errors, touched }) => (
                        <Form className="w-full flex flex-col gap-6">


                            <div className="grid md:grid-cols-1 md:gap-6">

                                <div className="flex flex-col">
                                    <label htmlFor="password">Password</label>
                                    <Field
                                        type="password"
                                        name="password"
                                        id="password"
                                        className={`border-2 rounded border-gray-400 outline-none px-2 py-1 ${errors.password && touched.password ? 'border-red-500' : ''
                                            }`}
                                    />
                                    <ErrorMessage name="password" component="div" className="text-red-500" />
                                </div>
                                <div className="flex flex-col">
                                    <label htmlFor="password">Conform Password</label>

                                    <Field
                                        type="password"
                                        name="confirmPassword"
                                        id="confirmPassword"
                                        className={`border-2 rounded border-gray-400 outline-none px-2 py-1 ${errors.confirmPassword && touched.confirmPassword ? 'border-red-500' : ''
                                            }`}
                                    />
                                    <ErrorMessage name="confirmPassword" component="div" className="text-red-500" />
                                </div>
                            </div>
                            <button
                                type="submit"
                                className="text-white capitalize bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                            >
                                Change Password
                            </button>
                        </Form>
                    )}
                </Formik>
            </div>
        </div>
    );
};

export default ResetPassword;


import React, { useEffect, useState } from 'react'

import { CheckCircle } from "react-feather";

import { Main } from '../../layouts/Main';
import { HOST_API_KEY } from '../../../config';
import { jwtDecode } from 'jwt-decode';
import { getAllOrdersByUserID } from '../../../apis/order';
import { Link, useParams } from 'react-router-dom';

const MyOrders = () => {
  const [userOrders,setUserOrders]=useState([])
  const {user_id} = useParams();
  console.log("id in paramas my orders",user_id)

  
  const FetchAllOrdersByUser =  async ()=>{
    const res = await getAllOrdersByUserID(user_id)
    localStorage.setItem("userOrders",JSON.stringify(res.data))
    setUserOrders(res.data)
    console.log("res",res)
  }

  
  // }, [])
  useEffect(() => {
      FetchAllOrdersByUser();
    }, [])


  return (
    <Main>
      <div className='flex justify-center items-center w-full'>
      <div className='flex justify-center items-center flex-col mx-10 my-4 px-4 py-4 lg:w-2/4 md:w-3/4 sm:w-full'> 
      <div className='flex justify-start items-center w-full'>
      <p className=' text-2xl my-7 font-bold text-left '>My Orders</p>

      </div>
      {
        userOrders?.map((order) => {
          console.log("order in map ",order)
return (
  <div className='flex justify-center items-center flex-col bg-slate-100 rounded-lg w-full my-2 px-3 pt-3 pb-1 '>
    <div className='flex justify-center items-start w-full flex-col border-b-[1px]'>
      <p className=' text-black text-lg '>Order # {order?.id}</p>
      <p className=' text-black text-lg '>Placed on {new Date(order?.created_at).toLocaleDateString('en-US')}</p>
    </div>
<div className=' flex justify-center items-center flex-col w-full my-2 '>
  {
    order?.items?.map(item => {
      return (
        <> 
        <div className=' py-2 w-full flex justify-between items-center'>
          <div className='flex justify-start items-center'>
          <img className='w-[40px] h-[40px] cover' src={`${HOST_API_KEY}${item?.image}`}/>
          <h5 className='px-2'>
            Qty : {" "}
          {item?.quantity}
         </h5>
          </div>
          <div className='flex justify-start items-center'>
          <span className='bg-gray-200 rounded-xl border-[1px] border-gray-200 px-4 py-[1px]' >
              status
          </span>
          </div>
          <div className='flex justify-start items-center'>
          <Link to={`/review/${item.item_id}/${order?.id}`}  className='rounded-lg  px-1 py-1 border-sky-500 text-sky-500 hover:underline'>
            Write a review 
          </Link>
          </div>
        </div>
       
</>
      )
    })
  }
   
  </div>
</div>



      
  )
        }
       )}
      </div>
      </div>
     
   
     

    </Main>
  )
}

export default MyOrders
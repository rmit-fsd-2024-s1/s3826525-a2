import { jwtDecode } from "jwt-decode";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";

const UserSetting = () => {
 const Navigate = useNavigate();
 const [userLogin,setUserLogin]=useState(null)
 const handleLogout = () => {
  Swal.fire({
   title: "Are you sure?",
   text: "Your account will be logout",
   icon: "warning",
   showCancelButton: true,
   confirmButtonColor: "#3085d6",
   cancelButtonColor: "#d33",
   confirmButtonText: "Logout",
  }).then((result) => {
   if (result.isConfirmed) {
    console.log("the user have been logout");
    localStorage.clear();
    setTimeout(() => {
     Navigate("/");
    }, 1000);
    Swal.fire({
     position: "center",
     icon: "success",
     title: "Logout",
     showConfirmButton: false,
     timer: 1000,
    });
   }
  });
 };
 useEffect(()=>{
    const user =jwtDecode(localStorage.getItem("jwtToken"))
    console.log("the user",user)
    setUserLogin(user)
 },[])
 return (
  <>
   <div className="flex justify-between items-center my-5 px-6">
    <Link
     to="/user-edit"
     className="text-gray-500 hover:text-gray-900 hover:bg-gray-200 rounded transition duration-150 ease-in font-medium text-sm text-center w-full py-3"
    >
     Edit Profile
    </Link>
    
    <Link
     to="/user-goal-setting"
     className="text-gray-500 hover:text-gray-900 hover:bg-gray-200 rounded transition duration-150 ease-in font-medium text-sm text-center w-full py-3"
    >
     Goal Setting
    </Link>
    <Link
     to="/user-meal-planing"
     className="text-gray-500 hover:text-gray-900 hover:bg-gray-200 rounded transition duration-150 ease-in font-medium text-sm text-center w-full py-3"
    >
     Meal Planing
    </Link>
    <Link
     to={`/my-reviews/${userLogin?.id}`}
     className="text-gray-500 hover:text-gray-900 hover:bg-gray-200 rounded transition duration-150 ease-in font-medium text-sm text-center w-full py-3"
    >
     My Reviews
    </Link>
    <Link
     to={`/my-orders/${userLogin?.id}`}
     className="text-gray-500 hover:text-gray-900 hover:bg-gray-200 rounded transition duration-150 ease-in font-medium text-sm text-center w-full py-3"
    >
     View Orders
    </Link>
    <button
     onClick={handleLogout}
     className="text-gray-500 hover:text-gray-900 hover:bg-gray-200 rounded transition duration-150 ease-in font-medium text-sm text-center w-full py-3"
    >
     Logout
    </button>
   </div>
  </>
 );
};

export default UserSetting;

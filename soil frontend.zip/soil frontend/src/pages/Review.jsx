import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import ReactStars from 'react-stars'
import { Main } from '../layouts/Main';
import { ErrorMessage, Field, Form, Formik } from 'formik';
import * as Yup from "yup";
import { products } from '../data';
import { jwtDecode } from 'jwt-decode';
import { UpdateReview, createNewRiview,getPreviousReview } from '../../apis/review';
import Swal from "sweetalert2";

const Review = () => {
  let { id } = useParams();
  let { order_id } = useParams();
  const [star, setStar] = useState(0);
  const [data, setData] = useState(null);
  const [ratingStatus, setRatingStatus] = useState('');
  const [loginUser, setLoginUser] = useState(null);
  const [loding,setLoding]=useState(false);
  const [defaultReview,setDefaultReview]= useState(null)
  const [isEdit,setIsEdit]= useState(false)
  const [shouldRerender, setShouldRerender] = useState(false);
  const Navigate = useNavigate();

  const fetchPreviousReview = async ()=>{
    try{
      setLoding(true)
      if (id && loginUser?.id && order_id) {
        const params = {
          item_id: id,
          user_id: loginUser?.id,
          order_id: order_id
      };
        console.log("idsObject before calling api",params)
        const res = await getPreviousReview(params);
        if(res.status===200){
          setDefaultReview(res?.data?.review);
          setIsEdit(true);
          setLoding(false)
        }else{
          setDefaultReview(null);
          setIsEdit(false);
          setLoding(false)
        }
        console.log("res.data",res?.data?.review);
       
      }
    }
    catch(err){
      console.log(err)
    }
    finally{
      setLoding(false)
    }
  }

  const ratingStatuses = {
    1: 'Poor',
    2: 'Fair',
    3: 'Good',
    4: 'Very Good',
    5: 'Excellent',
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoding(true)
        const products = JSON.parse(localStorage.getItem('products'));
        const user = jwtDecode(localStorage.getItem('jwtToken'));
        console.log("user", user);
        setData(products);
        setLoginUser(user);
      } catch (err) {
        console.error(err);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    const handleFetchPreviousReview = async () => {
      if (loginUser) {
        await fetchPreviousReview();
        setLoding(false);
      }
    };
    handleFetchPreviousReview();
  }, [loginUser]);


  const ratedProduct = products.filter((item)=>item.id == id)


  const ratingChanged = (newRating) => {
    setStar(newRating);
    setRatingStatus(ratingStatuses[Math.ceil(newRating)]);
    localStorage.setItem(`rating_${id}`, newRating);
  };

  useEffect(() => {
    const storedRating = localStorage.getItem(`rating_${id}`);
    if (storedRating !== null) {
      const parsedRating = parseFloat(storedRating);
      setStar(parsedRating);
      setRatingStatus(ratingStatuses[Math.ceil(parsedRating)]);
    }
  }, [id]);


 
    const initialValues = {
      comment: defaultReview && defaultReview.comment ? defaultReview.comment : '',
    };
  
  const validationSchema = Yup.object({
    
    comment: Yup.string(),
  });

  const onSubmit = async (values, { resetForm }) => {
    if(isEdit){
      const ratingPObject = {
        item_id: defaultReview?.item_id,
        rating: star,
        comment: values?.comment,
        user_id: defaultReview?.user_id,
        order_id:order_id
      }
      const ratingRes = await UpdateReview(defaultReview?.id,ratingPObject)
      if(ratingRes.status===201){
        console.log("rating res",ratingRes)
        setDefaultReview(ratingRes?.data?.review)
        Swal.fire({
          position: 'center',
          icon:'success',
          title: 'Your review has been Updated successfully',
          showConfirmButton: false,
          timer: 1500,
        });
       
      }else(
        Swal.fire({
          position: 'center',
          icon:'error',
          title: 'Something went wrong',
          showConfirmButton: false,
          timer: 1500,
        })
      )
    }
    if(!isEdit){
      console.log("values in not edit",values)
      console.log("values",values)
      const ratingPObject = {
        item_id: id,
        rating: star,
        comment: values?.comment,
        user_id: loginUser?.id,
        order_id:order_id
      }
      console.log("ratingPObject on create function",ratingPObject)
      const ratingRes = await createNewRiview(ratingPObject)
      if(ratingRes.status===201){
        console.log("rating res",ratingRes)
        setIsEdit(true)
        Swal.fire({
          position: 'center',
          icon:'success',
          title: 'Your review has been submitted successfully',
          showConfirmButton: false,
          timer: 1500,
        });
        setTimeout(() => {
          Navigate('/user-profile');
        }, 1500);
      }else(
        Swal.fire({
          position: 'center',
          icon:'error',
          title: 'Something went wrong',
          showConfirmButton: false,
          timer: 1500,
        })
      )
    }
    
   
  }
  return (
    <Main>
      {loding?<h4>loading ...</h4>:  <div className="flex justify-center items-center mx-4 my-4 flex-col">
        <div key={shouldRerender} className=' lg:w-2/4 md:w-3/4 sm:w-full w-full '>
          <p>My Reviews</p>
          <div className="flex justify-center items-center md:flex-row sm:flex-col flex-col  bg-gray-100 rounded-lg px-2 py-3 my-2">
            <div className='lg:w-1/4 md:w-1/4 sm:w-full w-full flex justify-center items-center'>
              <p className=' font-semibold text-base'>Select Product Rating</p>
            </div>
            <div className='lg:w-3/4 md:w-3/4 sm:w-full w-full flex justify-center items-center flex-col'>
              <ReactStars
                count={5}
                value={star}
                onChange={ratingChanged}
                size={24}
                color2={"#ffd700"}
              />
              {star > 0 && <p> {ratingStatus}</p>}
            </div>

          </div>
          <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={onSubmit}
          >

            {({ errors, touched,setFieldValue  }) => (
              <Form className="flex flex-col gap-8">
                <div className="flex justify-center items-center md:flex-row sm:flex-col flex-col  bg-gray-100 rounded-lg px-2 py-3">
                  <div className='lg:w-1/4 md:w-1/4 sm:w-full w-full flex justify-center items-center'>
                    <p className=' font-semibold text-base'>Write a commit</p>
                  </div>
                  <div className='lg:w-3/4 md:w-3/4 sm:w-full w-full flex justify-center items-center'>
                    <div className="w-full">
                      <Field
                        autoComplete="off"
                        className={`p-2 border w-full ${errors.comment && touched.comment
                          ? "border-red-500"
                          : "border-black"
                          }`}
                        as="textarea"
                        id="comment"
                        name="comment"
                        placeholder="Comment"
                      />
                      <ErrorMessage
                        name="password"
                        component="div"
                        className="text-red-500"
                      />
                    </div>
                  </div>
                </div>
                <div className="w-full my-2 ">
                  <button className="w-full rounded-lg bg-[#343643] py-2 text-white" type="submit">
                    {defaultReview && defaultReview.comment ?"Resubmit":"Submit"}
                  </button>
                </div>
              </Form>
            )}
          </Formik>
        </div>

      </div>}
    
    </Main>


  )
}

export default Review;
const PriceFilter = () => {
 return (
  <>
   <div className="price w-full bg-gray-400 mb-6">
    <select className="w-full outline-none" name="" id="">
     <option value="" defaultValue>
      Price
     </option>
     <option value="Price1">Price1</option>
     <option value="Price2">Price2</option>
     <option value="Price3">Price3</option>
     <option value="Price4">Price4</option>
     <option value="Price5">Price5</option>
    </select>
   </div>
  </>
 );
};

export default PriceFilter;

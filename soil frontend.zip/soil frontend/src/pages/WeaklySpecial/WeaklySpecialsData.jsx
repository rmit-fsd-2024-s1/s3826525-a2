import React from "react";

const WeaklySpecialsData = () => {
 return <div>WeaklySpecialsData</div>;
};

export default WeaklySpecialsData;

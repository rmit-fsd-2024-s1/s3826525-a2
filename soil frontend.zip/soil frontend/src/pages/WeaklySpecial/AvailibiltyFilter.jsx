const AvailibiltyFilter = () => {
 return (
  <>
   <div className="availebilty w-full bg-gray-400 mb-6">
    <select className="w-full outline-none" name="" id="">
     <option value="" defaultValue>
      Availebilty
     </option>
     <option value="availebilty1">availebilty1</option>
     <option value="availebilty2">availebilty2</option>
     <option value="availebilty3">availebilty3</option>
     <option value="availebilty4">availebilty4</option>
     <option value="availebilty5">availebilty5</option>
    </select>
   </div>
  </>
 );
};

export default AvailibiltyFilter;

const BransFilter = () => {
 return (
  <>
   <div className="brand w-full bg-gray-400 mb-6">
    <select className="w-full outline-none" name="" id="">
     <option value="" defaultValue>
      Brand
     </option>
     <option value="brand1">brand1</option>
     <option value="brand2">brand2</option>
     <option value="brand3">brand3</option>
     <option value="brand4">brand4</option>
     <option value="brand5">brand5</option>
    </select>
   </div>
  </>
 );
};

export default BransFilter;

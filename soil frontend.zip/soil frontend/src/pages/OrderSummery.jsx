import React, { useState } from 'react'
import { Main } from '../layouts/Main'
import { CheckCircle } from "react-feather";
import { HOST_API_KEY } from '../../config';

const OrderSummery = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleAccordion = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };
    const orderDetails = JSON.parse(localStorage.getItem("orderDetail"))
    console.log("order detail item in summery",orderDetails)
    const Subtotal = orderDetails?.items?.reduce((acc,item)=>acc+ item?.total,0)
    const totalAmount  = (Subtotal + 4 + 4)
    console.log("Subtotal",totalAmount)

  return (
    <Main>
      <div className='flex justify-center items-center flex-col bg-slate-100 rounded-lg mx-10 my-10 px-4 py-4'>
      <CheckCircle color='green' />
      <p className=' text-green-700 text-xl '>Thank you for your purchase !</p>
      <p className=' text-black text-lg '>your order number is {orderDetails?.id
}</p>
<div className='  bg-gray-50 rounded-lg flex justify-center items-center flex-col w-2/4 my-2 px-7'>
<div className='flex justify-end items-center py-2 w-full'>
  <h5 className=' font-bold text-gray-400 pr-2'>Delivery: </h5>
  <h5 className='text-right'>
              {`Est ${new Date(Date.now()).toLocaleDateString('en-US', { day: '2-digit', month: 'short' })}-${new Date(Date.now() + 10 * 86400000).toLocaleDateString('en-US', { day: '2-digit', month: 'short' })}`}
              </h5>
  </div>
 
      {
        orderDetails?.items?.map(item => {
          return (
            <> 
            <div className=' px-2 py-2 w-full flex justify-between items-center'>
              <img className='w-[40px] h-[40px] cover' src={`${HOST_API_KEY}${item?.image}`}/>
              <p>{item.quantity} x {item.price} = {item.total }</p>

            </div>
           
</>
          )
        })
      }
       <div className=' px-2 py-2 w-full flex justify-between items-center border-t-2'>
              <h5>to track the delivery of your order,go to <span className='text-black font-bold'>my order </span></h5>
              <button className='rounded-lg border-[1px] px-1 py-1 border-sky-500 text-sky-500'>
                View Order
              </button>
            </div>
      </div>
  <div className='w-2/4 mt-3' id="accordion-collapse" data-accordion="collapse">
      <h2 id="accordion-collapse-heading-1">
        <button
          type="button"
          className="flex items-center justify-between w-full p-5 font-medium rtl:text-right text-gray-500 border border-b-0 border-gray-200 rounded-t-xl focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 gap-3"
          onClick={() => toggleAccordion(1)}
          aria-expanded={activeIndex === 1}
          aria-controls="accordion-collapse-body-1"
        >
          <div className='flex justify-between items-center w-full'>
          <span>Order Summery</span>
          <span>${totalAmount}</span>
          </div>
         
          <svg
            data-accordion-icon
            className={`w-3 h-3 transform ${activeIndex === 1 ? 'rotate-180' : ''} shrink-0`}
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 10 6"
          >
            <path
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M9 5L5 1 1 5"
            />
          </svg>
        </button>
      </h2>
      <div
        id="accordion-collapse-body-1"
        className={activeIndex === 1 ? 'block' : 'hidden'}
        aria-labelledby="accordion-collapse-heading-1"
      >
        <div className="p-5 border border-b-0 border-gray-200 dark:border-gray-700 dark:bg-gray-900 flex-col w-full">
          <div className='flex justify-between items-center my-2'>
          <p className="text-gray-500 dark:text-gray-400">
            SubTotal
          </p>
          <p className="text-gray-500 dark:text-gray-400">
            $ {Subtotal}
          </p>
          </div>
          <div className='flex justify-between items-center my-2'>
          <p className="text-gray-500 dark:text-gray-400">
            Shipping Fee
          </p>
          <p className="text-gray-500 dark:text-gray-400">
          $ 4 
          </p>
          </div>
          <div className='flex justify-between items-center my-2'>
          <p className="text-gray-500 dark:text-gray-400">
            Tax
          </p>
          <p className="text-gray-500 dark:text-gray-400">
          $ 4
          </p>
          </div>
          <div className='flex justify-between items-center my-2 border-t-2'>
          <p className="text-gray-500 dark:text-gray-400">
            Total Amount 
          </p>
          <p className="text-gray-500 dark:text-gray-400">
          ${totalAmount}
          </p>
          </div>
          
        </div>
      </div>
    </div>
  

   
            </div>

    </Main>
  )
}

export default OrderSummery
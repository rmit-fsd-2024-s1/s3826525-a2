import axios from 'axios'
import { HOST_API_KEY } from '../config'

const axiosInstance = axios.create({baseURL: HOST_API_KEY, validateStatus: ((status) => {return status < 500})})
axiosInstance.interceptors.response.use(
    (response) => response,
    (error) => {
      window.alert("Network Error. Check your internet connection and try again.");
      return Promise.reject((error.response && error.response.data) || 'Something went wrong');
    }
);

  export  {axiosInstance};
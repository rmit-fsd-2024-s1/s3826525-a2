import { axiosInstance } from "../utils/axios"
import { PRODUCTS } from "./constants"

const getAllProdutct = ()=>{
    const res = axiosInstance.get(PRODUCTS);
    console.log(res.data)
    return res;
}

export {getAllProdutct}
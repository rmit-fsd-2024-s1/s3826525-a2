import { axiosInstance } from "../utils/axios";
import { ORDER, USERORDERS } from "./constants";

const createOrder = async (body)=>{
    const responce = await axiosInstance.post(ORDER,body);
    console.log("responce in order.js",responce)
    return responce;
}
const getOrderDetailById = async (id)=>{
    const responce = await axiosInstance.get(`${ORDER}/${id}`);
    console.log("responce in order details",responce)
    return responce;
}
const getAllOrdersByUserID = async (id)=>{
    const responce = await axiosInstance.get(`${USERORDERS}/${id}`);
    console.log("responce in order details",responce)
    return responce;
}
export {createOrder,getOrderDetailById,getAllOrdersByUserID};

import { User } from "react-feather";
import { axiosInstance } from "../utils/axios";
import { REVIEW } from "./constants";



const createNewRiview = async (body) => {
    const responce = await axiosInstance.post(REVIEW, body);
    console.log("responce",responce)
    return responce;
}

const getPreviousReview = async (params) => {
    console.log(params)
    const responce = await axiosInstance.get(REVIEW, { params });
    console.log("responce", responce);
    return responce;
}
const getReviewsByUserId = async (id) => {
    console.log(id)
    const responce = await axiosInstance.get(`${REVIEW}/${id}`);
    console.log("responce", responce);
    return responce;
}

const UpdateReview = async(id,body)=>{
    const responce = await axiosInstance.put(`${REVIEW}/${id}`,body);
    console.log(responce)
    return responce;
}
export { createNewRiview,getPreviousReview,UpdateReview,getReviewsByUserId};
const USERS = './users'
const RESETPASSWORD = './users/reset-password'
const SENDCODE = '/users/send-token'
const LOGIN = '/users/login'
const ORDER ='/order'
const USERORDERS ='/Userorders'
const PRODUCTS ='/products'
const REVIEW ='/review'


export {USERS,LOGIN,ORDER,SENDCODE,RESETPASSWORD,PRODUCTS,USERORDERS,REVIEW};
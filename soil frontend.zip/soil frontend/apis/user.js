import { User } from "react-feather";
import { axiosInstance } from "../utils/axios";
import { USERS,LOGIN,SENDCODE, RESETPASSWORD } from "./constants";


const fetchAllUsers = async () => {

    const responce = await axiosInstance.get(USERS);

    return responce
}

const createNewUser = async (body) => {
    const responce = await axiosInstance.post(USERS, body);
   
    return responce;
}

const userLogin = async(body)=>{
    const responce = await axiosInstance.post(LOGIN, body);
    return responce;
}
const sendEmail =async(email)=>{
    const responce = await axiosInstance.post(SENDCODE, email);
    console.log("responce at send email", responce);
    return responce;
}
const resetPassword =async(token,body)=>{
    console.log("token in api ",token)
    console.log("body in api",body)
    const responce = await axiosInstance.post(`${RESETPASSWORD}/${token}`, body);
    console.log("responce at reset password", responce);
    return responce;
}
const UpdateUser = async(id,body)=>{
    const responce = await axiosInstance.put(`${USERS}/${id}`,body);
    return responce;
}
const DeleteUser = async(id)=>{
    const responce = await axiosInstance.delete(`${USERS}/${id}`);
    console.log("responce at delete user", responce);
    return responce;
}
export { fetchAllUsers, createNewUser,userLogin,DeleteUser,UpdateUser,sendEmail,resetPassword};
to run the code

Soil Frontend

1. Extract Zip folder
2. Go into root directory
   Run Command
   a. npm i
   b. npm run dev

Soil Backend

1. Extract Zip folder
2. Go into root directory
   Run Command
   a. npm I
   b. npm start

Github URL : https://github.com/rmit-fsd-2024-s1/s3826525-a2
